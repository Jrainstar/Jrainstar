﻿//using NLog;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Moon
//{
//    public class DotNetLogger : ILogger
//    {
//        public static NLog.ILogger logger = LogManager.GetCurrentClassLogger();
//        public void Error(string error)
//        {
//            logger.Error(error);
//        }

//        public void Info(string info)
//        {
//            Console.WriteLine(logger);
//            logger.Info(info);
//        }

//        public void Warn(string warn)
//        {
//            logger.Warn(warn);
//        }
//    }
//}
